#!/bin/bash
. /root/.bash_profile

nohup ./ThrMeteM >>/zfmd/wpfs20/IIImete/log/mainout.log 2>&1 &

