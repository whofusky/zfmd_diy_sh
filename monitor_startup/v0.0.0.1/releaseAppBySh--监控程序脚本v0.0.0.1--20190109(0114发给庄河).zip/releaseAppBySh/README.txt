
#                       README


fs20            #forecast 2.0 project
personal        #relatively personal
README.txt      #a brief description
shfunc          #self-witten shell function
skytest.sh      #test script
testdir         #test directory
tool            #common shell tool written by myself

General note: The "relsh" directory in each subdirectory is used when publishing the  software or script of the corresponding directory 

