
#                       README

#############################################################################
#author       :    fushikai
#date         :    20181227
#linux_version:    Red Hat Enterprise Linux Server release 6.7
#dsc          :
#
#############################################################################


#Each file or directory is described below:

    #----fcust.sh       #personal environment variable customixation script
    #----mete           #Zone 3 weather download package directory
    #----readme.txt     #read me file
    #----startup        #shell script:monitor whether each configuration program starts and starts an unstarted program
    #----initsh         #2.0 project and operating system initialization related scripts
    #----maintainsh     #script to maintain related operations



