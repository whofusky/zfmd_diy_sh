
#                       README

#############################################################################
#author       :    fushikai
#date         :    20181017
#linux_version:    Red Hat Enterprise Linux Server release 6.7
#dsc          :
#    Mainly to implement a shell script to automate the 
#    deployment of the program
#
#############################################################################


#The recommended execution order is as follows:

#install:
    #----1    chmod +x relsh/*.sh
    #----2    relsh/relmetesh.sh 
    #----3    relsh/modifymetecfg.sh <old_farm_name> <new_farm_name>

#update:
    #----1    chmod +x relsh/*.sh
    #----2    relsh/upmete.sh 



